#include <iostream>
#include <cmath>
#include <cstdlib>

void suma() {
    double a, b;
    std::cout << "Ingrese el primer número: ";
    std::cin >> a;
    std::cout << "Ingrese el segundo número: ";
    std::cin >> b;
    double resultado = a + b;
    std::cout << "La suma de " << a << " y " << b << " es: " << resultado << std::endl;
}

void resta() {
    double a, b;
    std::cout << "Ingrese el primer número: ";
    std::cin >> a;
    std::cout << "Ingrese el segundo número: ";
    std::cin >> b;
    double resultado = a - b;
    std::cout << "La resta de " << a << " y " << b << " es: " << resultado << std::endl;
}

void multiplicacion() {
    double a, b;
    std::cout << "Ingrese el primer número: ";
    std::cin >> a;
    std::cout << "Ingrese el segundo número: ";
    std::cin >> b;
    double resultado = a * b;
    std::cout << "La multiplicación de " << a << " y " << b << " es: " << resultado << std::endl;
}

void division() {
    double a, b;
    std::cout << "Ingrese el numerador: ";
    std::cin >> a;
    std::cout << "Ingrese el denominador: ";
    std::cin >> b;
    if (b != 0) {
        double resultado = a / b;
        std::cout << "La división de " << a << " entre " << b << " es: " << resultado << std::endl;
    } else {
        std::cout << "Error: No se puede dividir por cero." << std::endl;
    }
}

void random_number() {
    int numero_aleatorio = rand() % 1001;
    std::cout << "Número aleatorio entre 0 y 1000: " << numero_aleatorio << std::endl;
}

void suma_lista() {
    std::cout << "Ingrese una lista de números separados por espacios: ";
    double numero;
    double resultado = 0;
    while (std::cin >> numero) {
        resultado += numero;
    }
    std::cout << "La suma de los números es: " << resultado << std::endl;
}

void raiz_cuadrada() {
    double numero;
    std::cout << "Ingrese un número para calcular su raíz cuadrada: ";
    std::cin >> numero;
    if (numero >= 0) {
        double resultado = sqrt(numero);
        std::cout << "La raíz cuadrada de " << numero << " es: " << resultado << std::endl;
    } else {
        std::cout << "Error: No se puede calcular la raíz cuadrada de un número negativo." << std::endl;
    }
}

void potencia() {
    double base, exponente;
    std::cout << "Ingrese la base: ";
    std::cin >> base;
    std::cout << "Ingrese el exponente: ";
    std::cin >> exponente;
    double resultado = pow(base, exponente);
    std::cout << base << " elevado a la " << exponente << " es: " << resultado << std::endl;
}

void logaritmo() {
    double numero;
    std::cout << "Ingrese un número para calcular su logaritmo en base 10: ";
    std::cin >> numero;
    if (numero > 0) {
        double resultado = log10(numero);
        std::cout << "El logaritmo en base 10 de " << numero << " es: " << resultado << std::endl;
    } else {
        std::cout << "Error: El logaritmo en base 10 solo está definido para números positivos." << std::endl;
    }
}

void seno() {
    double angulo;
    std::cout << "Ingrese el ángulo en radianes: ";
    std::cin >> angulo;
    double resultado = sin(angulo);
    std::cout << "El seno de " << angulo << " radianes es: " << resultado << std::endl;
}

void coseno() {
    double angulo;
    std::cout << "Ingrese el ángulo en radianes: ";
    std::cin >> angulo;
    double resultado = cos(angulo);
    std::cout << "El coseno de " << angulo << " radianes es: " << resultado << std::endl;
}

void tangente() {
    double angulo;
    std::cout << "Ingrese el ángulo en radianes: ";
    std::cin >> angulo;
    double resultado = tan(angulo);
    std::cout << "La tangente de " << angulo << " radianes es: " << resultado << std::endl;
}

void grados_a_radianes() {
    double grados;
    std::cout << "Ingrese el ángulo en grados: ";
    std::cin >> grados;
    double radianes = grados * (M_PI / 180);
    std::cout << grados << " grados equivalen a " << radianes << " radianes" << std::endl;
}

void radianes_a_grados() {
    double radianes;
    std::cout << "Ingrese el ángulo en radianes: ";
    std::cin >> radianes;
    double grados = radianes * (180 / M_PI);
    std::cout << radianes << " radianes equivalen a " << grados << " grados" << std::endl;
}

int main() {
    while (true) {
        std::cout << "\nMenu:\n";
        std::cout << "1. Suma de dos números\n";
        std::cout << "2. Resta de dos números\n";
        std::cout << "3. Multiplicación de dos números\n";
        std::cout << "4. División de dos números\n";
        std::cout << "5. Creación de números aleatorios de 0 a 1000\n";
        std::cout << "6. Suma de una lista de números\n";
        std::cout << "7. Cálculo de la raíz cuadrada de un número\n";
        std::cout << "8. Cálculo de una potencia\n";
        std::cout << "9. Cálculo del logaritmo en base 10\n";
        std::cout << "10. Cálculo del seno de un ángulo en radianes\n";
        std::cout << "11. Cálculo del coseno de un ángulo en radianes\n";
        std::cout << "12. Cálculo de la tangente de un ángulo en radianes\n";
        std::cout << "13. Conversión de grados a radianes\n";
        std::cout << "14. Conversión de radianes a grados\n";
        std::cout << "15. Salir del programa\n";

        int opcion;
        std::cin >> opcion;

        switch (opcion) {
            case 1:
                suma();
                break;
            case 2:
                resta();
                break;
            case 3:
                multiplicacion();
                break;
            case 4:
                division();
                break;
            case 5:
                random_number();
                break;
            case 6:
                suma_lista();
                break;
            case 7:
                raiz_cuadrada();
                break;
            case 8:
                potencia();
                break;
            case 9:
                logaritmo();
                break;
            case 10:
                seno();
                break;
            case 11:
                coseno();
                break;
            case 12:
                tangente();
                break;
            case 13:
                grados_a_radianes();
                break;
            case 14:
                radianes_a_grados();
                break;
            case 15:
                std::cout << "Saliendo del programa." << std::endl;
                return 0;
            default:
                std::cout << "Opción no válida. Por favor, elija una opción válida." << std::endl;
        }
    }

    return 0;
}